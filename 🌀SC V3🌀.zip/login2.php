<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $user_file = "user.txt";

    // Membaca data pengguna dari file
    $file_data = file($user_file, FILE_IGNORE_NEW_LINES);

    // Loop melalui baris data dalam file
    $login_successful = false;
    foreach ($file_data as $line) {
        list($stored_username, $stored_password) = explode(',', $line);

        if ($username === $stored_username && $password === $stored_password) {
            // Login berhasil, atur tanda berhasil
            $login_successful = true;
            break;
        }
    }

    if ($login_successful) {
        // Set cookie untuk mengingat bahwa pengguna telah berhasil login
        setcookie("loggedin", "1");

        // Redirect ke halaman menu
        header("Location: rafa.php");
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Dulu Cok</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --accent: #4895ef;
            --success: #4cc9f0;
            --danger: #f72585;
            --dark: #1a1a2e;
            --light: #f8f9fa;
            --glass: rgba(26, 26, 46, 0.8);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, var(--dark), #16213e);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--light);
            overflow: hidden;
            position: relative;
        }

        .cyber-container {
            perspective: 1000px;
            width: 100%;
            max-width: 400px;
            padding: 2rem;
            z-index: 10;
        }

        .cyber-card {
            background: var(--glass);
            backdrop-filter: blur(10px);
            border-radius: 16px;
            padding: 2.5rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(0, 240, 255, 0.2);
            text-align: center;
            position: relative;
            overflow: hidden;
            transform-style: preserve-3d;
            transition: transform 0.5s;
        }

        .cyber-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                to bottom right,
                transparent 45%,
                rgba(72, 149, 239, 0.1) 50%,
                transparent 55%
            );
            transform: rotate(30deg);
            animation: shine 6s infinite linear;
        }

        @keyframes shine {
            0% { transform: rotate(30deg) translate(-30%, -30%); }
            100% { transform: rotate(30deg) translate(30%, 30%); }
        }

        .cyber-header {
            margin-bottom: 2rem;
            position: relative;
        }

        .cyber-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent);
            margin-bottom: 0.5rem;
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        .cyber-subtitle {
            font-size: 0.9rem;
            color: rgba(248, 249, 250, 0.7);
            letter-spacing: 1px;
        }

        .cyber-divider {
            height: 2px;
            width: 80px;
            background: linear-gradient(to right, transparent, var(--accent), transparent);
            margin: 1rem auto;
            opacity: 0.7;
        }

        .cyber-form-group {
            margin-bottom: 1.5rem;
            text-align: left;
        }

        .cyber-label {
            display: block;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            color: var(--accent);
            font-weight: 500;
            letter-spacing: 1px;
        }

        .cyber-input {
            width: 100%;
            padding: 12px 15px 12px 40px;
            border-radius: 8px;
            border: 1px solid rgba(0, 240, 255, 0.3);
            background-color: rgba(10, 15, 30, 0.7);
            color: var(--light);
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .cyber-input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 2px rgba(72, 149, 239, 0.3);
        }

        .input-icon {
            position: relative;
        }

        .input-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--accent);
        }

        .cyber-btn {
            width: 100%;
            padding: 14px;
            border-radius: 8px;
            border: none;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: var(--light);
            font-family: 'Orbitron', sans-serif;
            font-size: 1rem;
            font-weight: 600;
            letter-spacing: 1px;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            z-index: 1;
            text-transform: uppercase;
            margin-top: 1rem;
        }

        .cyber-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: 0.5s;
            z-index: -1;
        }

        .cyber-btn:hover::before {
            left: 100%;
        }

        .cyber-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.6);
        }

        .cyber-btn:active {
            transform: translateY(0);
        }

        .cyber-error {
            color: var(--danger);
            font-size: 0.9rem;
            margin-top: -10px;
            margin-bottom: 15px;
            text-align: center;
            font-weight: 500;
        }

        .cyber-corner {
            position: absolute;
            width: 20px;
            height: 20px;
            border: 2px solid var(--accent);
            opacity: 0.7;
        }

        .corner-tl {
            top: 10px;
            left: 10px;
            border-right: none;
            border-bottom: none;
        }

        .corner-tr {
            top: 10px;
            right: 10px;
            border-left: none;
            border-bottom: none;
        }

        .corner-bl {
            bottom: 10px;
            left: 10px;
            border-right: none;
            border-top: none;
        }

        .corner-br {
            bottom: 10px;
            right: 10px;
            border-left: none;
            border-top: none;
        }

        .cyber-particles {
            position: absolute;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            background-color: var(--accent);
            border-radius: 50%;
            opacity: 0.7;
            animation: float-up linear infinite;
        }

        @keyframes float-up {
            to {
                transform: translateY(-100vh);
                opacity: 0;
            }
        }

        @media (max-width: 576px) {
            .cyber-container {
                padding: 1rem;
            }
            
            .cyber-card {
                padding: 1.5rem;
            }
            
            .cyber-title {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="cyber-particles" id="particles"></div>
    
    <div class="cyber-container">
        <div class="cyber-card">
            <div class="cyber-corner corner-tl"></div>
            <div class="cyber-corner corner-tr"></div>
            <div class="cyber-corner corner-bl"></div>
            <div class="cyber-corner corner-br"></div>
            
            <div class="cyber-header">
                <h1 class="cyber-title">LOGIN PANEL</h1>
                <div class="cyber-divider"></div>
                <p class="cyber-subtitle">AUTHENTICATION REQUIRED</p>
            </div>
            
                        
            <form method="POST">
                <div class="cyber-form-group">
                    <label class="cyber-label">USERNAME</label>
                    <div class="input-icon">
                        <i class="fas fa-user-astronaut"></i>
                        <input type="text" class="cyber-input" name="username" placeholder="Enter your username" required>
                    </div>
                </div>
                
                <div class="cyber-form-group">
                    <label class="cyber-label">PASSWORD</label>
                    <div class="input-icon">
                        <i class="fas fa-key"></i>
                        <input type="password" class="cyber-input" name="password" placeholder="Enter your password" required>
                    </div>
                </div>
                
                <button type="submit" class="cyber-btn">
                    <i class="fas fa-sign-in-alt"></i> LOGIN
                </button>
            </form>
        </div>
    </div>

    <script>
        // Create floating particles
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            const colors = ['#4361ee', '#3f37c9', '#4895ef', '#4cc9f0'];
            
            for (let i = 0; i < 20; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                // Random properties
                const size = Math.random() * 8 + 2;
                const posX = Math.random() * window.innerWidth;
                const duration = Math.random() * 10 + 5;
                const delay = Math.random() * 5;
                
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                particle.style.left = `${posX}px`;
                particle.style.bottom = '0px';
                particle.style.animationDuration = `${duration}s`;
                particle.style.animationDelay = `${delay}s`;
                particle.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
                
                particlesContainer.appendChild(particle);
                
                // Remove particle after animation completes
                setTimeout(() => {
                    particle.remove();
                }, duration * 1000);
            }
        }

        // Create particles periodically
        createParticles();
        setInterval(createParticles, 3000);
    </script>
</body>
</html>